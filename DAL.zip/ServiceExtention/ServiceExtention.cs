﻿using $safeprojectname$;
using Microsoft.EntityFrameworkCore;


namespace Microsoft.Extensions.DependencyInjection
{


    public static class ServiceExtention
    {
        /// <summary>
        /// تزریق کانتکست به برنامه
        /// </summary>
        /// <param name="services"></param>
        /// <param name="ConnectionString"></param>
        /// <returns></returns>
        public static IServiceCollection AddAlphaCore(this IServiceCollection services, string ConnectionString)
        {
            var service = services.AddDbContext<AlphaCoreContext>
                (opt => opt.UseSqlServer(ConnectionString));
            return service;
        }


        /// <summary>
        /// تزریق کانتکست به برنامه
        /// </summary>
        /// <param name="services"></param>
        /// <param name="ConnectionString"></param>
        /// <returns></returns>
        public static IServiceCollection AddAlphaCoreSqlite(this IServiceCollection services, string ConnectionString)
        {
            var service = services.AddDbContext<AlphaCoreContext>
                (opt => opt.UseSqlite(ConnectionString));
            return service;
        }


        public static IServiceCollection AddAlphaCoreSqlite<T>(this IServiceCollection services, string ConnectionString) where T : DbContext
        {
            var service = services.AddDbContext<T>
                (opt => opt.UseSqlite(ConnectionString));
            return service;
        }


    }



}
