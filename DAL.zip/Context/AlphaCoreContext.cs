﻿using Microsoft.EntityFrameworkCore;
using Shared.Models;

namespace $safeprojectname$
{
    public class AlphaCoreContext : DbContext
    {
        public AlphaCoreContext(DbContextOptions<AlphaCoreContext> options) : base(options)
        {

        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            base.OnConfiguring(optionsBuilder);
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {




            #region SeedData
            //تنظیمات عمومی
            modelBuilder.Entity<GeneralSetting>()
                .HasData(new GeneralSetting() { Id = 1, SiteName = "", LogoPath = "" });
            //نقش ها
            modelBuilder.Entity<Role>()
                .HasData(
                new Role() { Id = 1, Name = "برنامه نویس" },
                new Role() { Id = 2, Name = "مدیر" },
                new Role() { Id = 3, Name = "کاربر  معمولی" }
                );
            #endregion

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<GeneralSetting> generalSettings { get; set; }
        public DbSet<AppUser> appUsers { get; set; }
        public DbSet<Role> roles { get; set; }
        public DbSet<AppUserRole> appUserRoles { get; set; }



    }
}
