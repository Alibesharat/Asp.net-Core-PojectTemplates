﻿using Newtonsoft.Json;

namespace $safeprojectname$
{


    public class HistoryBaseModel
    {
       [JsonIgnore]
       public string Hs_Change { get; set; }

       public bool IsDeleted { get; set; }
    }
}
