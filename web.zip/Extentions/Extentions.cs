﻿using Shared.Models;
using Newtonsoft.Json;
using System.Linq;
using System.Security.Claims;

namespace $safeprojectname$.Extentions
{
    public static class Extentions
    {
        /// <summary>
        /// دیافت شماره تلفن
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static string PhoneNumber(this ClaimsPrincipal user)
        {
            return user.Claims.FirstOrDefault(c => c.Type == ClaimTypes.MobilePhone)?.Value;
        }



        public static AppUser GetUserinfo(this ClaimsPrincipal user)
        {
            var s = user.Claims.FirstOrDefault(c => c.Type == ClaimTypes.UserData)?.Value;
            if (string.IsNullOrWhiteSpace(s)) return null;
            var data = JsonConvert.DeserializeObject<AppUser>(s);
            return data;
        }



    }
}
