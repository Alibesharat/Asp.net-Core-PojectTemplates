﻿using Shared.Models;
using DNTPersianUtils.Core;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{

    public class AuthController : Controller
    {
        private readonly IDistributedCache _cache;

        public AuthController(IDistributedCache cache)
        {
            _cache = cache;
        }

        [HttpGet]
        public IActionResult UerChalenge()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UerChalenge([FromForm] RegisterUserViewModel model)
        {


            if (ModelState.IsValid)
            {
                if (!model.PhoneNumber.IsValidIranianMobileNumber())
                {
                    ViewBag.msg = "شماره تلفن همراه معتبر نمی باشد";
                    return View();
                }
                string token = Const.GeneratRandomNumber();


                var options = new DistributedCacheEntryOptions()
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(3)
                };
                await _cache.SetStringAsync(model.PhoneNumber, token, options);
            }
           
            //await _notify.SendNotifyWithTemplateAsync(phoneNumber, token, MessageTemplate.Bisroverify);
            return RedirectToAction(nameof(ValidateingNumber), new { model.PhoneNumber });
        }


        public IActionResult ValidateingNumber(string phoneNumber)
        {
            ViewBag.phoneNumber = phoneNumber;
            ViewBag.newrequset = false;
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> ValidateingNumber([FromForm] VerifyUserViewModel model)
        {
            var c = await _cache.GetStringAsync(model.PhoneNumber);
            ViewBag.newrequset = false;
            if (c == null)
            {
                ViewBag.msg = "این کد منقضی شده است لطفا یک کد دیگر درخواست کنید";
                ViewBag.phoneNumber = model.PhoneNumber;
                ViewBag.newrequset = true;
                return View();
            }
            if (c == model.Code)
            {
                var user = new AppUser();
                //add in database
                await AddAuthAsync(user);
                return RedirectToLocal("");
            }
            ViewBag.msg = "کد وارد شده معتبر نمی باشد";
            ViewBag.phoneNumber = model.PhoneNumber;
            return View();
        }




        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        [HttpPost]
        public IActionResult LogOut()
        {
            return SignOut(
                new AuthenticationProperties() { RedirectUri = "/Account/login" },
                CookieAuthenticationDefaults.AuthenticationScheme);
        }


        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Denied()
        {
            return View();
        }


        [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View();
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }



        private async Task AddAuthAsync(AppUser data)
        {
            var claimes = new List<Claim>();
            string userdata = JsonConvert.SerializeObject(data);
            claimes.Add(new Claim(ClaimTypes.Name, data.Name));
            //   claimes.Add(new Claim(ClaimTypes.Role, RolName.Parrent.ToString()));
            //claimes.Add(new Claim(ClaimTypes.UserData, userdata));
            var ClaimIdentity = new ClaimsIdentity("RolName.Parrent.ToString()");
            ClaimIdentity.AddClaims(claimes);
            var userPrincipal = new ClaimsPrincipal(ClaimIdentity);
            await HttpContext.SignInAsync(
                       CookieAuthenticationDefaults.AuthenticationScheme,
                       userPrincipal,
                       new AuthenticationProperties
                       {
                           ExpiresUtc = DateTime.UtcNow.AddDays(15),
                           IsPersistent = true,
                           AllowRefresh = true
                       });
        }

    }
}