﻿using $safeprojectname$.Models;
using DAL;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;

namespace $safeprojectname$.Controllers
{

    public class HomeController : Controller
    {
        private readonly AlphaCoreContext _context;



        public HomeController(AlphaCoreContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {

            //_context.ArticleCategories.Add(new DAL.Models.ArticleCategory()
            // {
            //     Name = "دوچرخه"
            // });
            // _context.SaveChangesAsync();
            // var s = _context.ArticleCategories.ToList();
            if (User.Identity.IsAuthenticated)
            {
                var name = User.Identity.Name;
            }
            return View();
        }

        public IActionResult About()
        {


            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
