﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public interface ISms
    {
        Task<string> SendWithTemplateAsync(string phonenumber, string Token, string template);
        string SendWithTemplate(string phonenumber, string Token, string template);

        string SendBulk(List<string> PhoneNumbers, string Message);
    }




}
