﻿
using System;
using System.Text.RegularExpressions;

public class Const
{

    public const string WebSiteName = "کانون زبان ایران";

    public const string kewords = "طراحی وبسایت";

    /// <summary>
    /// آدرس وبسایت
    /// </summary>
    public const string WebSitePath = "http://kanon.tamam.ir";
    /// <summary>
    /// مسیر پیش فرض آواتار
    /// </summary>
    public const string DefaulAvatarPath = "~/avatars/default.png";

    /// <summary>
    /// مسیر پیش فرض تصاویر بندانگشتی
    /// </summary>
    public const string DefaultTumbnailPath = "~/tumbs/default.png";

    public static string Generatetoken()
    {
        return Regex.Replace(Convert.ToBase64String(Guid.NewGuid().ToByteArray()), "[/+=]", "");
    }


    public static string GeneratRandomNumber()
    {
        Random r = new Random();
        return r.Next(1342, 9895).ToString();

    }


}

