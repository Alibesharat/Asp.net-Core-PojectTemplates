﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.ViewModels
{
    /// <summary>
    /// ویومدل ثبت نام کاربر
    /// </summary>
    public class RegisterUserViewModel
    {
        [Display(Name = "شماره موبایل")]
        [Required(ErrorMessage = "شماره موبایل الزامی است")]
        [Phone]
        public string PhoneNumber { get; set; }

    }


    /// <summary>
    ///تایید پیامک کاربر
    /// </summary>
    public class VerifyUserViewModel
    {
        [Display(Name = "شماره موبایل")]
        [Required(ErrorMessage = "شماره موبایل الزامی است")]
        [Phone]
        public string PhoneNumber { get; set; }

        [Display(Name = "کد تایید")]
        [Required(ErrorMessage = "کد تایید است")]
      
        public string Code { get; set; }

    }
}
