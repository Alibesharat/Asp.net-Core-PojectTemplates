﻿using AutoHistoryCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// کلاس رابط کاربر و نقش 
    /// برای پیاده سازی ارتباط چند به چند
    /// </summary>
    public class AppUserRole : HistoryBaseModel
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey(nameof(appUser))]
        public int UserId { get; set; }
        public AppUser appUser { get; set; }


        [ForeignKey(nameof(role))]
        public int RolIds { get; set; }
        public Role role { get; set; }
    }
}