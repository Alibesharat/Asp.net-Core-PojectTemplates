﻿using AutoHistoryCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// کلاس نقش
    /// </summary>
    public class Role : HistoryBaseModel
    {
        public Role()
        {
            appUserRoles = new HashSet<AppUserRole>();
        }

        [Key]
        public int Id { get; set; }

        [Display(Name = "عنوان نقش")]
        public string Name { get; set; }

        public virtual ICollection<AppUserRole> appUserRoles { get; set; }
    }
}