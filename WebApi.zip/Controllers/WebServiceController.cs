﻿using AlphaCoreLogger;
using AlphaNotify;
using DAL;
using Microsoft.AspNetCore.Mvc;


namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// ApiController
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class WebServiceController : ControllerBase
    {
        private readonly AlphaCoreContext _context;
        private readonly ICoreLogger _logger;
        private ISms _sms;

        public WebServiceController(AlphaCoreContext context, ICoreLogger logger, ISms sms)
        {
            _context = context;
            _logger = logger;
            _sms = sms;
        }













































    }
}
